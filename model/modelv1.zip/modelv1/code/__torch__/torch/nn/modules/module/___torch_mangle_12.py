op_version_set = 1
class Module(Module):
  __parameters__ = ["weight_ih_l0", "weight_hh_l0", "bias_ih_l0", "bias_hh_l0", "weight_ih_l0_reverse", "weight_hh_l0_reverse", "bias_ih_l0_reverse", "bias_hh_l0_reverse", ]
  weight_ih_l0 : Tensor
  weight_hh_l0 : Tensor
  bias_ih_l0 : Tensor
  bias_hh_l0 : Tensor
  weight_ih_l0_reverse : Tensor
  weight_hh_l0_reverse : Tensor
  bias_ih_l0_reverse : Tensor
  training : bool
  bias_hh_l0_reverse : Tensor
  def forward(self: __torch__.torch.nn.modules.module.___torch_mangle_12.Module,
    batch_sizes: Tensor,
    input: Tensor,
    permutation: Tensor) -> Tensor:
    _0 = self.bias_hh_l0_reverse
    _1 = self.bias_ih_l0_reverse
    _2 = self.weight_hh_l0_reverse
    _3 = self.weight_ih_l0_reverse
    _4 = self.bias_hh_l0
    _5 = self.bias_ih_l0
    _6 = self.weight_hh_l0
    _7 = self.weight_ih_l0
    hx = torch.zeros([2, 1, 512], dtype=6, layout=0, device=torch.device("cpu"), pin_memory=False)
    _8, tensor, tensor0 = torch.lstm(input, batch_sizes, [hx, hx], [_7, _6, _5, _4, _3, _2, _1, _0], True, 1, 0., True, True)
    return _8
