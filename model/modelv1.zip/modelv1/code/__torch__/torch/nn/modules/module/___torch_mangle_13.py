op_version_set = 1
class Module(Module):
  __parameters__ = ["weight", "bias", ]
  weight : Tensor
  bias : Tensor
  training : bool
  def forward(self: __torch__.torch.nn.modules.module.___torch_mangle_13.Module,
    input: Tensor) -> Tensor:
    _0 = self.bias
    output = torch.matmul(input, torch.t(self.weight))
    return torch.add_(output, _0, alpha=1)
