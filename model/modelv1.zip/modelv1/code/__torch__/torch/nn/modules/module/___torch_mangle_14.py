op_version_set = 1
class Module(Module):
  __parameters__ = []
  training : bool
  word_embeddings : __torch__.torch.nn.modules.module.___torch_mangle_11.Module
  lstm : __torch__.torch.nn.modules.module.___torch_mangle_12.Module
  linear : __torch__.torch.nn.modules.module.___torch_mangle_13.Module
  def forward(self: __torch__.torch.nn.modules.module.___torch_mangle_14.Module,
    input: Tensor,
    lengths: Tensor) -> Tensor:
    _0 = self.linear
    _1 = self.lstm
    _2 = (self.word_embeddings).forward(input, )
    lengths0 = torch.to(lengths, torch.device("cpu"), 4, False, False, None)
    lengths1, sorted_indices = torch.sort(lengths0, -1, True)
    sorted_indices0 = torch.to(sorted_indices, dtype=4, layout=0, device=torch.device("cpu"), pin_memory=False, non_blocking=False, copy=False, memory_format=None)
    input0 = torch.index_select(_2, 0, sorted_indices0)
    input1, batch_sizes = torch._pack_padded_sequence(input0, lengths1, True)
    output = torch.empty_like(sorted_indices0, dtype=4, layout=0, device=torch.device("cpu"), pin_memory=False, memory_format=0)
    _3 = torch.arange(0, 1, 1, dtype=None, layout=0, device=torch.device("cpu"), pin_memory=False)
    permutation = torch.scatter_(output, 0, sorted_indices0, _3)
    _4 = (_1).forward(batch_sizes, input1, permutation, )
    max_seq_length = ops.prim.NumToTensor(torch.size(batch_sizes, 0))
    padded_output, lengths2 = torch._pad_packed_sequence(_4, batch_sizes, True, 0., int(max_seq_length))
    input2 = torch.index_select(padded_output, 0, permutation)
    return (_0).forward(input2, )
