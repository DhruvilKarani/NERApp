op_version_set = 1
class Module(Module):
  __parameters__ = ["weight", ]
  weight : Tensor
  training : bool
  def forward(self: __torch__.torch.nn.modules.module.___torch_mangle_11.Module,
    input: Tensor) -> Tensor:
    input0 = torch.embedding(self.weight, input, 739, False, False)
    return input0
